
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ShoppingCart, CheckCircle2, Package, Truck, MoreHorizontal, XCircle } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { PurchaseOrder } from "@/api/entities";
import { GoodsReceipt } from "@/api/entities";
import { InventoryLot } from "@/api/entities";
import { InventoryAudit } from "@/api/entities";
import { Brand } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";
import { logStatusChange, logAuditAction } from "../utils/auditLogger";
import SimpleConfirmDialog from "../common/SimpleConfirmDialog";

export default function GoodsReceiptsTab({ purchaseOrders, products, goodsReceipts, loading, canEdit, currentUser, onRefresh }) {
  const [brands, setBrands] = useState([]);
  const [receivingQuantities, setReceivingQuantities] = useState({});
  const [processingPO, setProcessingPO] = useState(null);
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const [closingPO, setClosingPO] = useState(null);
  const { toast } = useToast();

  React.useEffect(() => {
    loadBrands();
  }, []);

  const loadBrands = async () => {
    try {
      const brandsData = await Brand.list();
      setBrands(brandsData);
    } catch (error) {
      console.error("Error loading brands:", error);
    }
  };

  const getBrandName = (brandId) => {
    const brand = brands.find(b => b.id === brandId);
    return brand?.name || 'Unknown Brand';
  };

  const getProductInfo = (productId) => {
    return products.find(p => p.id === productId) || {};
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      case 'closed': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleQuantityChange = (poId, itemIndex, quantity) => {
    setReceivingQuantities(prev => ({
      ...prev,
      [`${poId}-${itemIndex}`]: parseInt(quantity) || 0
    }));
  };

  const getReceivedQuantityForItem = (poId, productId) => {
    const relatedGRNs = goodsReceipts.filter(grn => grn.purchase_order_id === poId);
    let totalReceived = 0;
    
    relatedGRNs.forEach(grn => {
      grn.items?.forEach(item => {
        if (item.product_id === productId) {
          totalReceived += item.received_quantity || 0;
        }
      });
    });
    
    return totalReceived;
  };

  const canClosePO = (po) => {
    if (!po.items || po.items.length === 0) return false;
    
    return po.items.every(item => {
      const totalReceived = getReceivedQuantityForItem(po.id, item.product_id);
      return totalReceived >= item.quantity;
    });
  };

  const handleReceiveItems = async (po) => {
    if (!canEdit) return;
    
    setProcessingPO(po.id);
    
    try {
      // Generate GRN number
      const timestamp = Date.now().toString().slice(-6);
      const grnNumber = `GRN-${timestamp}`;
      
      // Prepare items to receive
      const itemsToReceive = po.items?.map((item, index) => {
        const receivingQty = receivingQuantities[`${po.id}-${index}`] || 0;
        return {
          product_id: item.product_id,
          ordered_quantity: item.quantity,
          received_quantity: receivingQty,
          unit_price: item.unit_price,
          batch_no: `BATCH-${Date.now()}-${index}`,
          location: "Warehouse A"
        };
      }).filter(item => item.received_quantity > 0) || [];

      if (itemsToReceive.length === 0) {
        toast({
          title: "No items to receive",
          description: "Please enter quantities for items to receive",
          variant: "destructive"
        });
        setProcessingPO(null);
        return;
      }

      // Create GRN
      const grnData = {
        grn_number: grnNumber,
        purchase_order_id: po.id,
        supplier_id: po.supplier_id,
        receipt_date: new Date().toISOString().split('T')[0],
        received_by: currentUser.email,
        notes: `Received via goods receipt tab`,
        items: itemsToReceive
      };

      const newGRN = await GoodsReceipt.create(grnData);
      await logAuditAction("GoodsReceipt", newGRN.id, "create", currentUser.email, { grn_number: newGRN.grn_number });

      // Create inventory lots and audit entries
      for (const item of itemsToReceive) {
        // Create inventory lot
        const lotData = {
          product_id: item.product_id,
          batch_no: item.batch_no,
          location: item.location,
          qty_on_hand: item.received_quantity,
          cost_per_unit: item.unit_price,
          currency: po.currency || 'GBP',
          notes: `Received via GRN ${grnNumber}`,
          is_active: true
        };

        const newLot = await InventoryLot.create(lotData);

        // Create inventory audit entry
        await InventoryAudit.create({
          inventory_lot_id: newLot.id,
          product_id: item.product_id,
          adjustment_type: "increase",
          previous_qty: 0,
          adjusted_qty: item.received_quantity,
          difference: item.received_quantity,
          reason: `Goods received via PO ${po.po_number}`,
          reference_document: po.po_number,
          adjusted_by: currentUser.email,
          adjustment_date: new Date().toISOString()
        });
      }

      // Check if PO should be closed
      const updatedPO = { ...po };
      let shouldClose = true;
      
      updatedPO.items = po.items?.map(item => {
        const totalReceived = getReceivedQuantityForItem(po.id, item.product_id) + 
          (itemsToReceive.find(i => i.product_id === item.product_id)?.received_quantity || 0);
        
        if (totalReceived < item.quantity) {
          shouldClose = false;
        }
        
        return {
          ...item,
          received_quantity: totalReceived
        };
      });

      // Update PO status if all items are received
      if (shouldClose && po.status !== 'closed') {
        await PurchaseOrder.update(po.id, { status: 'closed' });
        await logStatusChange("PurchaseOrder", po.id, currentUser.email, po.status, 'closed', { reason: 'All items received' });

        toast({
          title: "Purchase Order Closed",
          description: `${po.po_number} has been automatically closed as all items are received.`
        });
      } else {
        toast({
          title: "Items Received",
          description: `${itemsToReceive.length} item(s) received via GRN ${grnNumber}`
        });
      }

      // Clear receiving quantities
      setReceivingQuantities(prev => {
        const newQuantities = { ...prev };
        po.items?.forEach((_, index) => {
          delete newQuantities[`${po.id}-${index}`];
        });
        return newQuantities;
      });

      onRefresh();
    } catch (error) {
      console.error("Error receiving items:", error);
      toast({
        title: "Error",
        description: "Failed to receive items. Please try again.",
        variant: "destructive"
      });
    } finally {
      setProcessingPO(null);
    }
  };

  const handleForceCloseClick = (po) => {
    setClosingPO(po);
    setShowCloseConfirm(true);
  };

  const handleConfirmForceClose = async () => {
    if (!closingPO || !canEdit) return;
    setProcessingPO(closingPO.id);
    try {
      await PurchaseOrder.update(closingPO.id, { status: 'closed' });
      await logStatusChange(
        "PurchaseOrder",
        closingPO.id,
        currentUser.email,
        closingPO.status,
        'closed',
        { reason: 'Manual force close by user.' }
      );
      toast({ title: "Success", description: `PO #${closingPO.po_number} has been closed.` });
      onRefresh();
    } catch (error) {
      console.error("Error force closing PO:", error);
      toast({ title: "Error", description: "Could not close the Purchase Order.", variant: "destructive" });
    } finally {
      setProcessingPO(null);
      setShowCloseConfirm(false);
      setClosingPO(null);
    }
  };

  if (loading) {
    return (
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="w-5 h-5" />
            Goods Receipts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <Skeleton className="h-20 w-full" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const openPOs = purchaseOrders.filter(po => po.status === 'submitted');

  return (
    <>
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="w-5 h-5" />
            Goods Receipts
          </CardTitle>
          <p className="text-sm text-gray-500 mt-1">
            Receive items from submitted purchase orders.
          </p>
        </CardHeader>
        <CardContent>
          {openPOs.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p className="font-semibold">No Submitted Purchase Orders</p>
              <p>There are no purchase orders awaiting goods receipt.</p>
            </div>
          ) : (
            <div className="space-y-6">
              {openPOs.map((po) => (
                <Card key={po.id} className="overflow-hidden">
                  <CardHeader className="bg-gray-50 p-4 border-b">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2">
                      <div className="min-w-0">
                        <h3 className="font-semibold text-lg text-gray-800">{po.po_number}</h3>
                        <p className="text-sm text-gray-600">{getBrandName(po.supplier_id)}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className="border-blue-300 text-blue-800 bg-blue-50">
                          {po.status?.toUpperCase()}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          {format(new Date(po.order_date), 'MMM dd, yyyy')}
                        </span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead className="min-w-[200px]">Product</TableHead>
                            <TableHead>Ordered</TableHead>
                            <TableHead>Received</TableHead>
                            <TableHead>Receiving Now</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {po.items?.map((item, index) => {
                            const product = getProductInfo(item.product_id);
                            const totalReceived = getReceivedQuantityForItem(po.id, item.product_id);
                            const remaining = item.quantity - totalReceived;
                            
                            return (
                              <TableRow key={index} className="bg-white">
                                <TableCell>
                                  <p className="font-medium text-gray-800 truncate">{product.product_name}</p>
                                  <p className="text-sm text-gray-500">{product.size}</p>
                                </TableCell>
                                <TableCell>{item.quantity}</TableCell>
                                <TableCell>{totalReceived}</TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    min="0"
                                    max={remaining}
                                    placeholder="0"
                                    value={receivingQuantities[`${po.id}-${index}`] || ''}
                                    onChange={(e) => handleQuantityChange(po.id, index, e.target.value)}
                                    disabled={!canEdit || remaining <= 0}
                                    className="w-24"
                                  />
                                </TableCell>
                              </TableRow>
                            );
                          })}
                        </TableBody>
                      </Table>
                    </div>
                  </CardContent>
                  <CardFooter className="bg-gray-50 p-4 border-t flex items-center justify-between">
                    <Button
                      size="sm"
                      onClick={() => handleReceiveItems(po)}
                      disabled={!canEdit || processingPO === po.id || po.items?.every(item => item.quantity - getReceivedQuantityForItem(po.id, item.product_id) <= 0)}
                      className="bg-emerald-600 hover:bg-emerald-700"
                    >
                      {processingPO === po.id ? "Processing..." : "Receive Items"}
                    </Button>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" disabled={processingPO === po.id}>
                          <MoreHorizontal className="w-5 h-5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem
                          onClick={() => handleForceCloseClick(po)}
                          disabled={!canEdit}
                          className="text-red-500 focus:text-red-600 cursor-pointer"
                        >
                          <XCircle className="w-4 h-4 mr-2" />
                          Force Close PO
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      <SimpleConfirmDialog
        open={showCloseConfirm}
        onOpenChange={setShowCloseConfirm}
        title="Force Close Purchase Order"
        description={`Are you sure you want to manually close PO #${closingPO?.po_number}? This should only be done if you are not expecting any more items. This action cannot be undone.`}
        onConfirm={handleConfirmForceClose}
        confirmText="Yes, Close PO"
        variant="destructive"
      />
    </>
  );
}
