
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format, isValid, parseISO } from "date-fns";
import { Customer } from "@/api/entities";
import QuotationActionsDropdown from "./QuotationActionsDropdown";

export default function QuotationList({ quotations, loading, canEdit, canOverride, currentUser, onEdit, onRefresh }) {
  const [customers, setCustomers] = useState([]);

  React.useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const customersData = await Customer.list();
      setCustomers(customersData);
    } catch (error) {
      console.error("Error loading customers:", error);
    }
  };

  const getCustomerName = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    return customer?.customer_name || 'Unknown Customer';
  };

  const formatDate = (dateString) => {
    if (!dateString) return '-';
    try {
      const date = typeof dateString === 'string' ? parseISO(dateString) : new Date(dateString);
      return isValid(date) ? format(date, 'MMM dd, yyyy') : '-';
    } catch (error) {
      return '-';
    }
  };

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'submitted': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatCurrency = (amount, currency = 'AED') => {
    const formatter = new Intl.NumberFormat('en-US', {
      style: 'decimal',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    return `${formatter.format(amount || 0)} ${currency}`;
  };

  const canPerformActions = (quotation) => {
    if (!canEdit) return false;
    if (canOverride) return true;
    return !['accepted', 'rejected', 'invoiced'].includes(quotation.status);
  };

  if (loading) {
    return (
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Quotations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 animate-pulse">
                <Skeleton className="h-12 w-12 rounded-lg" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-4 w-[200px]" />
                  <Skeleton className="h-4 w-[150px]" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Quotations ({quotations.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="hidden lg:block">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Quotation Number</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Quotation Date</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quotations.map((quotation) => (
                  <TableRow key={quotation.id} className="hover:bg-gray-50">
                    <TableCell className="font-medium">{quotation.quotation_number}</TableCell>
                    <TableCell>{getCustomerName(quotation.customer_id)}</TableCell>
                    <TableCell>{formatDate(quotation.quotation_date)}</TableCell>
                    <TableCell>{quotation.reference || '-'}</TableCell>
                    <TableCell>
                      <Badge className={`${getStatusColor(quotation.status)} border`}>
                        {quotation.status?.toUpperCase()}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {formatCurrency(quotation.total_amount || 0, quotation.currency)}
                    </TableCell>
                    <TableCell>
                      <QuotationActionsDropdown 
                        quotation={quotation}
                        canEdit={canPerformActions(quotation)}
                        canOverride={canOverride}
                        onEdit={onEdit}
                        onRefresh={onRefresh}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="lg:hidden space-y-4">
            {quotations.map((quotation) => (
              <Card key={quotation.id} className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{quotation.quotation_number}</h3>
                    <p className="text-sm text-gray-600">{getCustomerName(quotation.customer_id)}</p>
                  </div>
                  <Badge className={`${getStatusColor(quotation.status)} border`}>
                    {quotation.status?.toUpperCase()}
                  </Badge>
                </div>

                <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                  <div>
                    <p className="text-gray-500">Quotation Date</p>
                    <p className="font-medium">{formatDate(quotation.quotation_date)}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Reference</p>
                    <p className="font-medium">{quotation.reference || '-'}</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Total Amount</p>
                    <p className="font-medium">{formatCurrency(quotation.total_amount || 0, quotation.currency)}</p>
                  </div>
                </div>

                <div className="flex items-center justify-end pt-3 border-t border-gray-200">
                  <QuotationActionsDropdown 
                    quotation={quotation}
                    canEdit={canPerformActions(quotation)}
                    canOverride={canOverride}
                    onEdit={onEdit}
                    onRefresh={onRefresh}
                  />
                </div>
              </Card>
            ))}
          </div>

          {quotations.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No quotations found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </>
  );
}
