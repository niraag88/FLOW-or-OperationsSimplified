
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Edit2, Trash2, Save, X } from "lucide-react";
import { Customer } from "@/api/entities";
import { useToast } from "@/components/ui/use-toast";
import { logAuditAction } from "../utils/auditLogger";
import SimpleConfirmDialog from "../common/SimpleConfirmDialog"; // Added import

export default function CustomerManagement() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false); // Added state
  const [customerToDelete, setCustomerToDelete] = useState(null); // Added state

  const [formData, setFormData] = useState({
    customer_name: "",
    contact_name: "",
    address: "",
    type: "Local",
    trn_number: "",
    is_active: true
  });

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const customersData = await Customer.list('customer_name');
      setCustomers(customersData);
    } catch (error) {
      console.error("Error loading customers:", error);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({
      customer_name: "",
      contact_name: "",
      address: "",
      type: "Local",
      trn_number: "",
      is_active: true
    });
    setEditingCustomer(null);
    setShowForm(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const customerData = { ...formData };
      
      // Clear TRN if customer is International
      if (customerData.type === "International") {
        customerData.trn_number = "";
      }

      if (editingCustomer) {
        await Customer.update(editingCustomer.id, customerData);
        await logAuditAction("Customer", editingCustomer.id, "update", "admin@example.com", { updated_fields: Object.keys(customerData) });
        toast({
          title: "Success",
          description: "Customer updated successfully.",
        });
      } else {
        const newCustomer = await Customer.create(customerData);
        await logAuditAction("Customer", newCustomer.id, "create", "admin@example.com", { customer_name: customerData.customer_name });
        toast({
          title: "Success",
          description: "Customer created successfully.",
        });
      }

      loadCustomers();
      resetForm();
    } catch (error) {
      console.error("Error saving customer:", error);
      toast({
        title: "Error",
        description: "Failed to save customer.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (customer) => {
    setFormData(customer);
    setEditingCustomer(customer);
    setShowForm(true);
  };
  
  // Renamed from handleDelete and modified to open dialog
  const handleDeleteClick = (customer) => {
    setCustomerToDelete(customer);
    setDialogOpen(true);
  };

  // New function for confirming deletion
  const handleDeleteConfirm = async () => {
    if (!customerToDelete) return;

    try {
      await Customer.delete(customerToDelete.id);
      await logAuditAction("Customer", customerToDelete.id, "delete", "admin@example.com", { customer_name: customerToDelete.customer_name });
      toast({
        title: "Success",
        description: "Customer deleted successfully.",
      });
      loadCustomers();
    } catch (error) {
      console.error("Error deleting customer:", error);
      toast({
        title: "Error",
        description: "Failed to delete customer.",
        variant: "destructive",
      });
    } finally {
      setDialogOpen(false);
      setCustomerToDelete(null);
    }
  };

  const handleToggleActive = async (customer) => {
    try {
      await Customer.update(customer.id, { ...customer, is_active: !customer.is_active });
      await logAuditAction("Customer", customer.id, "status_change", "admin@example.com", { 
        status: { from: customer.is_active, to: !customer.is_active }
      });
      loadCustomers();
    } catch (error) {
      console.error("Error updating customer status:", error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold">Customer Management</h3>
          <p className="text-sm text-gray-600">Manage customer information and settings</p>
        </div>
        <Button onClick={() => setShowForm(true)} className="bg-emerald-600 hover:bg-emerald-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Customer
        </Button>
      </div>

      {/* Customer Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingCustomer ? 'Edit Customer' : 'Add New Customer'}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="customer_name">Customer Name *</Label>
                  <Input
                    id="customer_name"
                    value={formData.customer_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, customer_name: e.target.value.slice(0, 50) }))}
                    maxLength={50}
                    required
                  />
                  <p className="text-xs text-gray-500">{formData.customer_name.length}/50 characters</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="contact_name">Contact Name *</Label>
                  <Input
                    id="contact_name"
                    value={formData.contact_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, contact_name: e.target.value.slice(0, 20) }))}
                    maxLength={20}
                    required
                  />
                  <p className="text-xs text-gray-500">{formData.contact_name.length}/20 characters</p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  placeholder="Optional - will appear in invoice outputs if provided"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="type">Customer Type *</Label>
                  <Select 
                    value={formData.type} 
                    onValueChange={(value) => setFormData(prev => ({ ...prev, type: value, trn_number: value === "International" ? "" : prev.trn_number }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Local">Local</SelectItem>
                      <SelectItem value="International">International</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.type === "Local" && (
                  <div className="space-y-2">
                    <Label htmlFor="trn_number">TRN Number</Label>
                    <Input
                      id="trn_number"
                      value={formData.trn_number}
                      onChange={(e) => setFormData(prev => ({ ...prev, trn_number: e.target.value }))}
                      placeholder="Tax Registration Number"
                    />
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="is_active"
                  checked={formData.is_active}
                  onCheckedChange={(value) => setFormData(prev => ({ ...prev, is_active: value }))}
                />
                <Label htmlFor="is_active">Active Customer</Label>
              </div>

              <div className="flex justify-end gap-3">
                <Button type="button" variant="outline" onClick={resetForm}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button type="submit" disabled={loading}>
                  <Save className="w-4 h-4 mr-2" />
                  {loading ? "Saving..." : editingCustomer ? "Update Customer" : "Create Customer"}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Customers List */}
      <Card>
        <CardHeader>
          <CardTitle>Customers ({customers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Customer Name</TableHead>
                  <TableHead>Contact Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>TRN Number</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customers.map((customer) => (
                  <TableRow key={customer.id}>
                    <TableCell className="font-medium">{customer.customer_name}</TableCell>
                    <TableCell>{customer.contact_name}</TableCell>
                    <TableCell>
                      <Badge variant={customer.type === 'Local' ? 'default' : 'secondary'}>
                        {customer.type}
                      </Badge>
                    </TableCell>
                    <TableCell>{customer.trn_number || '-'}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={customer.is_active}
                          onCheckedChange={() => handleToggleActive(customer)}
                          size="sm"
                        />
                        <span className={customer.is_active ? 'text-green-600' : 'text-gray-400'}>
                          {customer.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(customer)}>
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => handleDeleteClick(customer)}
                          className="text-red-600 hover:text-red-800"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {customers.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              No customers found. Add your first customer to get started.
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Added SimpleConfirmDialog */}
      <SimpleConfirmDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onConfirm={handleDeleteConfirm}
        title="Confirm Deletion"
        description={`Do you wish to confirm deleting customer "${customerToDelete?.customer_name}"?`}
        confirmText="Yes, Delete"
        confirmVariant="destructive"
      />
    </div>
  );
}
